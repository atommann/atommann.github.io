/*********************************************
 * vim:sw=8:ts=8:si:et
 * To use the above modeline in vim you must have "set modeline" in your .vimrc
 * Author: Guido Socher
 * Copyright: GPL V2
 * See http://www.gnu.org/licenses/gpl.html
 *
 * Chip type           : Atmega88 or Atmega168 or Atmega328 with ENC28J60
 *********************************************/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <string.h>
#include <avr/pgmspace.h>
#include "ip_arp_udp_tcp.h"
#include "websrv_help_functions.h"
#include "enc28j60.h"
#include "timeout.h"
#include "ds18x20.h"
#include "onewire.h"
#include "net.h"

#define ATOMMANN

// Note: This software implements a web server and a web browser.
// The web server is at "myip" and the browser tries to access "websrvip".
//
// Please modify the following lines. mac and ip have to be unique
// in your local area network. You can not have the same numbers in
// two devices:
static uint8_t mymac[6] = {0x54,0x55,0x58,0x10,0x00,0x29};
// how did I get the mac addr? Translate the first 3 numbers into ascii is: TUX
// This web server's own IP.
#ifdef ATOMMANN
static uint8_t myip[4] = {192,168,1,2};
//static uint8_t myip[4] = {192,168,0,253}; // chaihuo
#else
static uint8_t myip[4] = {10,0,0,29};
//static uint8_t myip[4] = {192,168,255,100};
#endif
// IP address of the web server to contact (IP of the first portion of the URL):
#ifdef ATOMMANN
static uint8_t websrvip[4] = {97,74,215,60}; //atommann.com
#else
static uint8_t websrvip[4] = {77,37,2,152};  //tuxgraphics.org
//static uint8_t websrvip[4] = {10,0,0,1};
//static uint8_t websrvip[4] = {10,0,0,7};
#endif
// The name of the virtual host which you want to contact at websrvip (hostname of the first portion of the URL):
#ifdef ATOMMANN
#define WEBSERVER_VHOST "atommann.com"
#else
#define WEBSERVER_VHOST "tuxgraphics.org"
#endif
// Default gateway. The ip address of your DSL router. It can be set to the same as
// websrvip the case where there is no default GW to access the 
// web server (=web server is on the same lan as this host) 
#ifdef ATOMMANN
static uint8_t gwip[4] = {192,168,1,1};
//static uint8_t gwip[4] = {192,168,0,1}; // chaihuo
#else
static uint8_t gwip[4] = {10,0,0,2};
#endif
//
//static char urlvarstr[21];
static char urlvarstr[60];
// listen port for tcp/www:
#define MYWWWPORT 80
//

#define BUFFER_SIZE 550
static uint8_t buf[BUFFER_SIZE+1];
static uint8_t pingsrcip[4];
//static uint8_t start_web_client=0;
static volatile uint8_t start_web_client=0; // atommann add volatile
static uint8_t web_client_attempts=0;
static uint8_t web_client_sendok=0;
static volatile uint8_t sec=0;
static volatile uint8_t cnt2step=0;

static volatile uint8_t seconds;

// if you want to have a page where you can see debug information about the 
// attached sensors then set this to one (dbg) otherwise to zero:
#define DEBUG_SENSORS 0
// uncomment this is you want the graphs in farenheit
//#define GRAPH_IN_F
#define MAXSENSORS 5
static uint8_t gSensorIDs[MAXSENSORS][OW_ROMCODE_SIZE];
static int16_t gTempdata[MAXSENSORS]; // temperature times 10
static int8_t gNsensors=0;
#define TEMPHIST_BUFFER_SIZE 60
// how often (in minutes times 10, 12=120min, 24=240min) to record the data to a graph (max value=255 ):
static uint8_t rec_interval=12;
// position at which the EEPROM is used for storage of temp. data:
#define EEPROM_TEMP_POS_OFFSET 40 
static uint8_t gTemphistnextptr=0;

static volatile uint8_t gSec=0;
static volatile uint8_t gMeasurementTimer=0; // sec
static uint8_t gTemp_measurementstatus=0; // 0=ok,1=error


// set output to VCC, red LED off
#define LEDOFF PORTB|=(1<<PORTB1)
// set output to GND, red LED on
#define LEDON PORTB&=~(1<<PORTB1)
// to test the state of the LED
#define LEDISOFF PORTB&(1<<PORTB1)

// writes to global array gSensorIDs
int8_t search_sensors(void)
{
        uint8_t diff;
        uint8_t nSensors=0;
        for( diff = OW_SEARCH_FIRST;
                diff != OW_LAST_DEVICE && nSensors < MAXSENSORS ; )
        {
                DS18X20_find_sensor( &diff, &(gSensorIDs[nSensors][0]) );

                if( diff == OW_PRESENCE_ERR ) {
                        return(-1); //No Sensor found
                }
                if( diff == OW_DATA_ERR ) {
                        return(-2); //Bus Error
                }
                nSensors++;
        }
        return nSensors;
}

// start a measurement for all sensors on the bus:
void start_temp_meas(void){
        gTemp_measurementstatus=0;
        if ( DS18X20_start_meas(NULL) != DS18X20_OK) {
                gTemp_measurementstatus=1;
        }
}

// convert celsius times 10 values to Farenheit
int8_t c2f(int16_t celsiustimes10){
        return((int8_t)((int16_t)(celsiustimes10 * 18)/100) + 32);
}

// read the latest measurement off the scratchpad of the ds18x20 sensor
// and store it in gTempdata
void read_temp_meas(void){
        uint8_t i;
        uint8_t subzero, cel, cel_frac_bits;
        for ( i=0; i<gNsensors; i++ ) {

                if ( DS18X20_read_meas( &gSensorIDs[i][0], &subzero,
                                &cel, &cel_frac_bits) == DS18X20_OK ) {
                        gTempdata[i]=cel*10;
                        gTempdata[i]+=DS18X20_frac_bits_decimal(cel_frac_bits);
                        if (subzero){
                                gTempdata[i]=-gTempdata[i];
                        }
                }else{
                        gTempdata[i]=0;
                }
        }
}

uint16_t http200ok(void)
{
        return(fill_tcp_data_p(buf,0,PSTR("HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nPragma: no-cache\r\n\r\n")));
}


// prepare the webpage by writing the data to the tcp send buffer
uint16_t print_webpage(uint8_t *buf)
{
        uint16_t plen;
        char vstr[5];
        plen=http200ok();
        plen=fill_tcp_data_p(buf,plen,PSTR("<h2>web client status</h2>\n<pre>\n"));
        plen=fill_tcp_data_p(buf,plen,PSTR("Number of data uploads started by ping: "));
        // convert number to string:
        itoa(web_client_attempts,vstr,10);
        plen=fill_tcp_data(buf,plen,vstr);
        plen=fill_tcp_data_p(buf,plen,PSTR("\nNumber successful data uploads to web: "));
        // convert number to string:
        itoa(web_client_sendok,vstr,10);
        plen=fill_tcp_data(buf,plen,vstr);
        plen=fill_tcp_data_p(buf,plen,PSTR("\n</pre><br><hr>"));
        return(plen);
}

/* setup timer T2 as an interrupt generating time base.
* You must call once sei() in the main program */
void init_cnt2(void)
{
	cnt2step=0;
	PRR&=~(1<<PRTIM2); // write power reduction register to zero
	TIMSK2=(1<<OCIE2A); // compare match on OCR2A
	TCNT2=0;  // init counter
	OCR2A=244; // value to compare against
	TCCR2A=(1<<WGM21); // do not change any output pin, clear at compare match
	// divide clock by 1024: 12.5MHz/128=12207 Hz
	TCCR2B=(1<<CS22)|(1<<CS21)|(1<<CS20); // clock divider, start counter
	// 12207/244=50Hz, i.e. 20ms
}

// called when TCNT2==OCR2A
// that is in 50Hz intervals
ISR(TIMER2_COMPA_vect){
	cnt2step++;
	if (cnt2step>50){
                cnt2step=0;
                sec++; // stepped every second
                gMeasurementTimer++; // for ds18b20
                if (seconds++ >= 120) {        // period = 4 minuts
                        start_web_client = 1;
                        seconds = 0;
                }
	}
}

// we were ping-ed by somebody, store the ip of the ping sender
// and trigger an upload to http://tuxgraphics.org/cgi-bin/upld
// This is just for testing and demonstration purpose
void ping_callback(uint8_t *ip){
        uint8_t i=0;
        // trigger only first time in case we get many ping in a row:
        if (start_web_client==0){
                start_web_client=1;
                // save IP from where the ping came:
                while(i<4){
                        pingsrcip[i]=ip[i];
                        i++;
                }
        }
}

void browserresult_callback(uint8_t statuscode,uint16_t datapos){
        // datapos is not used in this example
        if (statuscode==0){
                web_client_sendok++;
                LEDOFF;
        }
}

int main(void){

    uint16_t dat_p;
    char str[30]; 
    char sensor1_str[5]; 
    char sensor2_str[5]; 
    uint8_t i;
    static int8_t state=0;
    
    // set the clock speed to "no pre-scaler" (8MHz with internal osc or 
    // full external speed)
    // set the clock prescaler. First write CLKPCE to enable setting of clock the
    // next four instructions.
    CLKPR=(1<<CLKPCE); // change enable
    CLKPR=0; // "no pre-scaler"
    _delay_loop_1(0); // 60us
    
    /*initialize enc28j60*/
    enc28j60Init(mymac);
    enc28j60clkout(2); // change clkout from 6.25MHz to 12.5MHz
    _delay_loop_1(0); // 60us
    
    init_cnt2();
    sei();
    
    /* Magjack leds configuration, see enc28j60 datasheet, page 11 */
    // LEDB=yellow LEDA=green
    //
    // 0x476 is PHLCON LEDA=links status, LEDB=receive/transmit
    // enc28j60PhyWrite(PHLCON,0b0000 0100 0111 01 10);
    enc28j60PhyWrite(PHLCON,0x476);
    
    DDRB|= (1<<DDB1); // LED, enable PB1, LED as output
    LEDOFF;
    
    //init the web server ethernet/ip layer:
    init_ip_arp_udp_tcp(mymac,myip,MYWWWPORT);
    // init the web client:
    client_set_gwip(gwip);  // e.g internal IP of dsl router
    client_set_wwwip(websrvip);
    //register_ping_rec_callback(&ping_callback); // atommann

    // initialize:
/*
    i=0;
    while(i<TEMPHIST_BUFFER_SIZE){
            store_temphist(0,i,0);
            store_temphist(0,i,1);
            i++;
    }
*/
    gNsensors=search_sensors();
    // initialize gTempdata in case somebody reads the web page immediately after reboot
    i=0;
    while(i<MAXSENSORS){
            gTempdata[i]=0;
            i++;
    }
    if (gNsensors>0){
            start_temp_meas();
    }

    
    while(1){
        // we need at least 750ms time between 
        // start of measurement and reading
        if (gMeasurementTimer==2 && state==0) {
                LEDON;
                read_temp_meas();
                state=1;
	}

        if (gMeasurementTimer==3 && state==1){
                LEDOFF;
                start_temp_meas();
                state=2;
        }

        if (gMeasurementTimer==5){ // every 5 sec new measurement:
                gMeasurementTimer=0;
                state=0;
        }
	
	// handle ping and wait for a tcp packet
	dat_p=packetloop_icmp_tcp(buf,enc28j60PacketReceive(BUFFER_SIZE, buf));
	if(dat_p==0){
	    if (start_web_client==1){
		LEDON;
		//sec=0;
		//start_web_client=2;
		start_web_client=0;
		web_client_attempts++;
		//mk_net_str(str,pingsrcip,4,'.',10);
		//urlencode(str,urlvarstr);
                //itoa(gTempdata[0]/10, sensor1_str, 10);
                //sensor1_str[2] = '.';
                //sensor1_str[3] = gTempdata[0]%10 + 0x30;

                //itoa(gTempdata[1]/10, sensor2_str, 10);
                //sensor2_str[2] = '.';
                //sensor2_str[3] = gTempdata[1]%10 + 0x30;

                str[0] = gTempdata[0]/100 + 0x30;
                str[1] = (gTempdata[0]/10)%10 + 0x30;
                str[2] = '.';
                str[3] = gTempdata[0]%10 + 0x30;

		urlencode(str, urlvarstr);
		//client_browse_url(PSTR("/cgi-bin/upld?pingIP="),urlvarstr,PSTR(WEBSERVER_VHOST),&browserresult_callback);
		// sensor1=20.0&sensor2=2.0
		client_browse_url(PSTR("/beertemp.php?sensor1=1.1&sensor2="),urlvarstr,PSTR(WEBSERVER_VHOST),&browserresult_callback);
	    }
	    // reset after a delay to prevent permanent bouncing
            // 1 minutes later, ping and sending data will be available again, atommann
	    ///if (sec>60 && start_web_client==2){
		//start_web_client=0;
	    //}
	    continue;
	}
	
	if (strncmp("GET ",(char *)&(buf[dat_p]),4)!=0){
	    // head, post and other methods:
	    //
	    // for possible status codes see:
	    // http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html
	    dat_p=http200ok();
	    dat_p=fill_tcp_data_p(buf,dat_p,PSTR("<h1>200 OK</h1>"));
	    goto SENDTCP;
	}
	if (strncmp("/ ",(char *)&(buf[dat_p+4]),2)==0){
	    dat_p=http200ok();
	    dat_p=print_webpage(buf);
	    goto SENDTCP;
	}else{
	    dat_p=fill_tcp_data_p(buf,0,PSTR("HTTP/1.0 401 Unauthorized\r\nContent-Type: text/html\r\n\r\n<h1>401 Unauthorized</h1>"));
	    goto SENDTCP;
	}
	//
    SENDTCP:
	www_server_reply(buf,dat_p); // send data
	
    }
    return (0);
}
