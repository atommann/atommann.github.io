#include <avr/io.h>
#include "button.h"

/******************************************************************
 * key scan state machine
 *****************************************************************/
uint8_t read_key(void)
{
    static char key_state = 0, key_press;
    uint8_t key_return = KEY_NO; // KEY_NO = 0

    key_press = KEY_INPUT & KEY_MASK;    // 读按键 I/O 电平

    switch (key_state)
    {
        case KEY_STATE_0:    // 按键初始态
            if (key_press != KEY_MASK) key_state = KEY_STATE_1; 
            break;           // 键被按下，状态转换到键确认态
        case KEY_STATE_1:    // 按键确认态
            if (key_press == (KEY_INPUT & KEY_MASK)) // 如果和上次按下的键相同
            {
                if (key_press == 0xFE)      // 0b1111 1110
                    key_return = KEY_ESC;   // 按键仍按下，按键确认输出为1
                else if (key_press == 0xFD) // 0b1111 1101
                    key_return = KEY_UP;
                else if (key_press == 0xFB) // 0b1111 1011
                    key_return = KEY_ENTER;
                else if (key_press == 0xF7) // 0b1111 0111
                    key_return = KEY_LEFT;
                else if (key_press == 0xEF) // 0b1110 1111
                    key_return = KEY_DOWN;
                else if (key_press == 0xDF) // 0b1101 1111
                    key_return = KEY_RIGHT;                
                key_state = KEY_STATE_2;    // 状态转换到键释放态
            }
            else
                key_state = KEY_STATE_0; // 按键已抬起，转换到按键初始态            
            break;
        case KEY_STATE_2:    // 按键初始态
            if (key_press == KEY_MASK) key_state = KEY_STATE_0; // 铵键已释放，转换到按键初始态
            break;
    }

    return key_return;
}
