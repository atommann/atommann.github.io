unsigned char bcd2bin(unsigned char data);
unsigned char bin2bcd(unsigned char data);
