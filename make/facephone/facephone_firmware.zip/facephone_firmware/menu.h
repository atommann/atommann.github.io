// menu.h

typedef struct PROGMEM
{
    unsigned char state;     // ״̬
    unsigned char input;     // ����
    unsigned char nextstate; // ��һ��״̬
} MENU_NEXTSTATE;


typedef struct PROGMEM
{
    unsigned char state;
    PGM_P pText;
    char (*pFunc)(char input);
} MENU_STATE;


// Menu text
// mtA, these where all of the same structure as in the follow. line
const char MT_CLOCK[] PROGMEM                = "Clock";
const char MT_CLOCK_ADJUST[] PROGMEM	     = "Adjust Clock";

const char MT_VCARD[] PROGMEM               = "Name";
const char MT_ENTERNAME[] PROGMEM           = "Enter name";

const MENU_NEXTSTATE menu_nextstate[] PROGMEM = {
//  state                       input       next state
	{ST_CLOCK,                  KEY_ENTER,  ST_SETUP},

	{ST_SETUP,                  KEY_ENTER,  ST_SETUP},
	{ST_SETUP,                  KEY_ESC,    ST_CLOCK},

    {ST_CLOCK_ADJUST,           KEY_ESC,    ST_CLOCK},

    {0,                            0,            0}
};


const MENU_STATE menu_state[] PROGMEM = {
//  stete                               state text                  state_func
    {ST_CLOCK,                          NULL,                       ShowClock},
    {ST_CLOCK_ADJUST,                   NULL,                       SetClock},
	{ST_SETUP,                          NULL,                        setup},

    {0,                                 NULL,                       NULL}
};
