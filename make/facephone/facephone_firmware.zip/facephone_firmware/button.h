#ifndef __BUTTON_H__
#define __BUTTON_H__

// key-related constant definition
#define KEY_INPUT   PINC /* connect port   */
#define KEY_MASK    0xFF /* mask           */

#define KEY_NO    0   /* no key pressed */
#define KEY_ESC   1   /* esc */
#define KEY_UP    2   /* up */
#define KEY_ENTER 3   /* enter */
#define KEY_LEFT  4   /* left */
#define KEY_DOWN  5   /* down */
#define KEY_RIGHT 6   /* right */

#define KEY_STATE_0 0 /* key state 0    */
#define KEY_STATE_1 1 /* key state 1    */
#define KEY_STATE_2 2 /* key state 2    */

// ����ԭ�Ͷ���
// uint8_t read_key(void);

#endif /* __BUTTON_H__ */
