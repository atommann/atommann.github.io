/********************************************************
*
* Date: 2007.9.2
* ---------------
*
* SDA and SCL pull up with 4.7k resistor
*
 *******************************************************/
#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>
#include "i2c.h"

void I2C_Init(void)
{
    cbi(I2C_PORT, SCL_BIT);
    cbi(I2C_PORT, SDA_BIT);
    sbi(I2C_DIR, SCL_BIT);
    cbi(I2C_DIR, SDA_BIT);
    _delay_us(5);
}

/***************************************************************
 * Function Name: I2C_Start
 * input        : void
 * return       : 1 - bus is free
 * *              0 - bus is buzy
 **************************************************************/
unsigned char I2C_Start(void)
{
    cbi(I2C_DIR, SDA_BIT);
    cbi(I2C_DIR, SCL_BIT);
    asm volatile("nop");

    if (!(inb(I2C_PIN)&(1<<SDA_BIT)))
        return 0;
    if (!inb(I2C_PIN)&(1<<SCL_BIT))
        return 0;

    _delay_us(2);
    sbi(I2C_DIR, SDA_BIT);
    _delay_us(2);
    sbi(I2C_DIR, SCL_BIT);
    _delay_us(2);

    return 1;
}

/**********************************
 * Function Name: I2C_Stop
 * input        : void
 * return       : void
 *********************************/
void I2C_Stop(void)
{
    sbi(I2C_DIR, SDA_BIT);
    sbi(I2C_DIR, SCL_BIT);
    _delay_us(5);
    cbi(I2C_DIR, SCL_BIT);
    _delay_us(2);
    cbi(I2C_DIR, SDA_BIT);
    _delay_us(5);
}

/***************************************************************
 *
 * read a byte from the bus
 * The ack parameter specifies if an acknowledgement is
 * to be issued after the byte was read.
 * Set ack to 0 for no acknowledgement or 1 for acknowledgement.
 *
 **************************************************************/
unsigned char I2C_Read(unsigned char ack)
{
    unsigned char i;
    unsigned char data = 0;

    for (i=8; i>0; i--)
    {
        cbi(I2C_DIR, SCL_BIT);
        _delay_us(2);

	while (!(inb(I2C_PIN)&(1<<SCL_BIT))) ;
        _delay_us(2);

        data <<= 1;

	if(inb(I2C_PIN)&(1<<SDA_BIT))
            data |= 1;
        sbi(I2C_DIR, SCL_BIT);
        _delay_us(5);
    }

    // send ack bit
    if (ack)
        sbi(I2C_DIR, SDA_BIT);  // sda=0, ack
    else
        cbi(I2C_DIR, SDA_BIT);  // sda=1, no ack

    _delay_us(2);
    cbi(I2C_DIR, SCL_BIT);
    _delay_us(5);
    sbi(I2C_DIR, SCL_BIT);
    _delay_us(2);
    cbi(I2C_DIR, SDA_BIT);
    _delay_us(2);

    return data;
}

/***************************************************************
 *
 * write the byte data to the bus
 * Returns 1 if the slave acknowledges or 0 if now.
 *
 **************************************************************/
unsigned char I2C_Write(unsigned char data)
{
    unsigned char i;
    unsigned char b;

    for (i=8; i>0; i--)
    {
        if (!(data & 0x80))
            sbi(I2C_DIR, SDA_BIT);
        else
            cbi(I2C_DIR, SDA_BIT);
        _delay_us(5);

        cbi(I2C_DIR, SCL_BIT);
        _delay_us(2);

        while (!(inb(I2C_PIN)&(1<<SCL_BIT))) ;
        _delay_us(2);

        sbi(I2C_DIR, SCL_BIT); // scl -> 0
        data <<= 1;
    }

    cbi(I2C_DIR, SDA_BIT);     // sda -> 1
    _delay_us(2);
    cbi(I2C_DIR, SCL_BIT);     // scl -> 1
    _delay_us(5);

    if(!(inb(I2C_PIN)&(1<<SDA_BIT)))
        b = 1;
    else
        b = 0;
    sbi(I2C_DIR, SCL_BIT);     // scl -> 0

    return b;
}
