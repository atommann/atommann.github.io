// main.h

void Initialization(void);
unsigned char StateMachine(char state, unsigned char stimuli);

#define BOOL    char

#define FALSE   0
#define TRUE    (!FALSE)

#define AUTO    3

// Macro definitions
// sbi and cbi are not longer supported by the avr-libc
// to avoid version-conflicts the macro-names have been
// changed to sbiBF/cbiBF "everywhere"
#define sbiBF(port,bit)  (port |= (1<<bit))   //set bit in port
#define cbiBF(port,bit)  (port &= ~(1<<bit))  //clear bit in port

// Menu state machine states
#define ST_CLOCK                        10
#define ST_CLOCK_ADJUST                 11
#define ST_SETUP                        20

#define CLOCK_24    1
#define CLOCK_12    0

// ����ԭ�Ͷ���
void init(void);
void timer0_init(void);
void timer2_init(void);
//void lcd_refresh(void);
unsigned char StateMachine(char state, unsigned char stimuli);

void dtmf(char digit);

