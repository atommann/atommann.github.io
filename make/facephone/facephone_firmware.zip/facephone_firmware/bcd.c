/* Macros to convert 2-digit BCD into binary and vice versa */
//#define	BIN2BCD(b)	(((b)%10) | (((b)/10)<<4))
//#define	BCD2BIN(b)	(((b)&0xf) + ((b)>>4)*10)

// data range: 0 to 9
unsigned char bin2bcd(unsigned char data)
{
    unsigned char i;

    i = data % 10;       // ��λ
    i |= ((data/10)<<4); // ʮλ

    return i;
}

unsigned char bcd2bin(unsigned char data)
{
    unsigned char i;

    i = data & 0x0F; // ȥ����4λ
    i += (data>>4)*10;

    return i;
}
