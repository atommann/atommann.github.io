// outb(), inb(), BV(), sbi(), cbi()
#define	 outb(addr, data)    ddr = (data)
#define	 inb(addr)           (addr)
#define BV(bit)             (1<<(bit))
#define cbi(reg,bit)        reg &= ~(BV(bit))
#define sbi(reg,bit)	      reg |= (BV(bit))

#define I2C_PORT PORTC
#define I2C_DIR  DDRC
#define I2C_PIN  PINC

#define SDA_BIT PC1
#define SCL_BIT PC0

void I2C_Init(void);
unsigned char I2C_Start(void);
void I2C_Stop(void);
unsigned char I2C_Read(unsigned char ack);
unsigned char I2C_Write(unsigned char data);
