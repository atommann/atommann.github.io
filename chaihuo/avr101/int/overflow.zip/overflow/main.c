#include <avr/io.h>
#define F_CPU 12000000UL
#include <util/delay.h>
#include <avr/interrupt.h> // sei(), cli() 和 ISR() 等中断相关的定义都在这个头文件里

// 全局变量
uint8_t seconds; // 秒
uint8_t minutes; // 分钟
uint8_t hours;   // 小时

volatile uint8_t counter; // 计数器

ISR (TIMER0_OVF_vect)
{
    if (counter++ >=181)
    {
        counter = 0;

        if (seconds++ > 59) // 如果秒钟满 60 秒
        {
            minutes = minutes + 1; // 分钟加一
            seconds = 0;           // 秒钟归零

            if (minutes++ > 59)    // 如果分钟满 60
            {
                hours = hours + 1; // 小时加一
                minutes = 0;       // 分钟归零

                if (hours++ > 23)  // 如果满 24 小时
                    hours = 0;     // 新的一天开始了！
            }
        }
        PORTC = seconds;
    }
}

ISR (INT1_vect)
{
    PORTC = PORTC ^ 0x01; // toggle LED
}

// 端口初始化
void init(void)
{
    DDRC = 0xFF; // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    // 设置 INT1
    EICRA = 0b00001000; // (1 << ISC11) 下降沿触发中断 see datasheet page 72
    EIMSK = 0b00000010; // (1 << INT1)  开启 INT1      see datasheet page 73

    // 设置 Timer 0
    TCCR0B = (1 << CS02);   // Prescaler 256
    TIMSK0 |= (1 << TOIE0); // 打开溢出中断功能
}

int main(void)
{

    init(); // 端口初始化
    sei();

    while (1)
    {
    }
}

