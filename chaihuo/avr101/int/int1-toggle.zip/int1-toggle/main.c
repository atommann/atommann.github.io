#include <avr/io.h>
#include <avr/interrupt.h> // 使用中断必须包含这个文件，sei(), cli() 和 ISR() 等中断相关的定义都在这个头文件里

// 外部中断1 (INT1) 中断服务例程
ISR (INT1_vect)
{
    PORTC = PORTC ^ 1; // (1) 翻转 LED 的状态
}

// 端口和 INT1 初始化
void init(void)
{
    DDRC = 0xFF; // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    // 设置化外部中断1
    EICRA = 0b00001000; // (1 << ISC11) 下降沿触发中断 see datasheet page 72
    EIMSK = 0b00000010; // (1 << INT1)  开启 INT1      see datasheet page 73
}

int main(void)
{
    init(); // 初始化
    sei();  // 开启全局中断

    while (1)
    {
        // 这里面什么都没有
    }
}
