#include <avr/io.h>
#define F_CPU 12000000UL // 12 MHz
#include <util/delay.h>
#include <avr/interrupt.h> // sei(), cli() 和 ISR() 等中断相关的定义都在这个头文件里

// 外部中断1 (INT1) 中断服务例程
ISR (INT1_vect)
{
    uint8_t i, temp;

    temp = PORTC;    // 先把 PORTC 里面的数据保存起来
 
    // 我们让 LED 闪烁 5 次
    for(i = 0; i<5; i++)
    {
        PORTC = 0b00000000;
        _delay_ms(500);      // 亮半秒钟(注意：在中断里使用延时不是好的编程习惯，这里仅供演示)
        PORTC = 0b11111111;
        _delay_ms(500);      // 灭半秒钟
    }

    PORTC = temp;            // 恢复 PORTC 的值
}

// 端口和 INT1 初始化
void init(void)
{
    DDRC = 0xFF; // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    // 设置化外部中断1
    EICRA = 0b00001000; // (1 << ISC11) 下降沿触发中断 see datasheet page 72
    EIMSK = 0b00000010; // (1 << INT1)  开启 INT1      see datasheet page 73
}

int main(void)
{
    unsigned char i;

    init(); // 初始化
    sei();  // 开启全局中断

    while (1)
    {
        for (i=0; i<6; i++)
        {
            PORTC = (1 << i); // 移位操作
            _delay_ms(500);
        }
    }
}
