#include <avr/io.h>
#define F_CPU 12000000UL  // 12 MHz
#include <util/delay.h>
#include <avr/pgmspace.h> // 访问程序空间，后面的 pgm_read_byte 函数就由这个库所提供

// 7-seg LED 段码表
// 位: 7  6 5 4 3 2 1 0
// 段: DP G F E D C B A
// 加额外的 PROGMEM (PROGram MEMory 的缩写)修饰是为了把表格
// 存储在 Flash 存储器(程序代码就是存储在这里的)里而非 RAM 里以节省内存
const uint8_t led_7[16] PROGMEM = {
0x3F, // 0
0x06, // 1
0x5B, // 2
0x4F, // 3
0x66, // 4
0x6D, // 5
0x7D, // 6
0x07, // 7
0x7F, // 8
0x6F, // 9
0x77, // A
0x7C, // b
0x39, // C
0x5E, // d
0x79, // E
0x71  // F
};

void init(void)
{
    DDRC = 0xFF;  // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    DDRB = 0xFF;  // 将 PORTB 设置成输出模式
    PORTB = 0x00;
}

int main(void)
{
    uint8_t i, temp;

    init();

    while (1)
    {
        for (i = 0; i < 16; i++)
        {
            temp = ~pgm_read_byte(led_7 + i); // 查表并赋给一个临时变量，因为是共阳LED，所要要把值取反(~是取反操作符)
            PORTC = temp;        // 把值赋给 IO
            PORTB = (temp >> 6); // 把数据向右移 6 位才能对应到 PB0 上
            _delay_ms(1000);
        }
    }
}

