#include <avr/io.h>
#include <avr/sleep.h>
#include "3310_routines.h"

/* defines */
#define FCPU		12000000UL // CPU freq
#define F_CPU FCPU
#include <util/delay.h>
#define ALL_INPUT	0x00 // 0000 0000
#define ALL_OUTPUT	0xFF // 1111 1111

int main(void)
{
	/* initialize port data directions */
	DDRB = ALL_OUTPUT;
	PORTB = 0xFF;

	/* set up */
	spi_init();

	/* get LCD ready */
	LCD_init();
	_delay_loop_2(65535);
	LCD_clear();
	LCD_drawSplash();
/*
    LCD_gotoXY (0,0);
    LCD_setPixel(0,0); // 画一个点

    LCD_gotoXY (0,1);                  // 设置显示的位置
    LCD_writeString_F("Hello World!"); // 显示一个字符串

    LCD_gotoXY (0,2);                  // 设置显示的位置
    LCD_writeString_F("MCU 101");      // 显示一个字符串
*/
	while(1)
	{
		//sleep_mode();
	}
}

