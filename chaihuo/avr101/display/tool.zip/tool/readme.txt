This tool is used to generate font table for 16-segment LED display.

The scheme version (in scm directory) is written by Nala Ginrut.

Usage

./sixteen > font16seg.h

or

make font
