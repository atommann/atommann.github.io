#include <avr/io.h>
#define F_CPU 12000000UL  // 12 MHz
#include <util/delay.h>
#include <avr/pgmspace.h> // 访问程序空间
#include <font16seg.h>    // 16 seg LED font table

// 各个端口初始化
void init(void)
{
    DDRC = 0xFF; // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    DDRB = 0xFF; // 将 PORTB 设置成输出模式
    PORTB = 0x00;

    DDRD = 0xFF; // 将 PORTD 设置成输出模式
    PORTD = 0x00;
}

// 显示一个字符
void led_put_char(char a)
{
    uint16_t temp;

    temp = pgm_read_word(font16seg + (a - 0x20)); // 查表，可打印字符是从0x20(空格)开始的，因此要减去这个偏移量
    PORTC = temp;      // 把最低的 6 位赋给 PORTC 0~5
    PORTB = temp >> 6; // 右移 6 位，赋给 PORTB 0~5
    PORTD = temp >> 9; // 右移 9 位，赋给 PORTD 3,4,5,6
}

// 显示字符串
void display_str(char *s)
{
    while (*s)
    {
        led_put_char(*s++);
        _delay_ms(500);
    }
}

// 显示完整的 ASCII 可打印字符表
void display_ascii_tab(void)
{
    char i;

    for (i = ' '; i <= '~'; i++)
    {
        led_put_char(i);
        _delay_ms(1000);
    }
}

// 显示一个简单的动画
void play_animation(void)
{
    uint8_t i;

    for(i = 0; i < 15; i++)
    {
        led_put_char('-');
        _delay_ms(50);
        led_put_char('\\');
        _delay_ms(50);
        led_put_char('|');
        _delay_ms(50);
        led_put_char('/');
        _delay_ms(50);
    }
}
 
int main(void)
{
    char i;

    init();

    while (1)
    {
        //led_put_char('A');            // 显示字母 A
        //display_str("Hello  World "); // 例行的 hello world
        //display_ascii_tab();          // 演示 ASCII 表
        play_animation();               // 演示动画
    }
}

