#include <avr/io.h>
#define F_CPU 12000000UL
#include <util/delay.h>
#include <avr/interrupt.h> // sei(), cli() 和 ISR() 等中断相关的定义都在这个头文件里

// key-related constant definition
#define KEY_INPUT   PINB /* connect port     */
#define KEY_MASK    0x3F /* mask 0b0011 1111 */

#define KEY_NO    0   /* no key pressed */
#define KEY_S1    1   /* S1 */
#define KEY_S2    2   /* S2 */
#define KEY_S3    3   /* S3 */

#define KEY_STATE_0 0 /* key state 0 */
#define KEY_STATE_1 1 /* key state 1 */
#define KEY_STATE_2 2 /* key state 2 */

// function prototypes
// uint8_t read_key(void);


// 全局变量
volatile uint8_t key_scan_time_ok;      // key scan ok
volatile uint8_t key_scan_time_counter; // read keys every 10ms


// Timer/Counter 0 溢出中断服务例程
ISR (TIMER0_OVF_vect) // 查 avr-libc manual
{
    // 5.5ms 中断一次

    if (++key_scan_time_counter >= 2) // check for 11ms, increament counter
    {
        key_scan_time_counter = 0;
        key_scan_time_ok = 1;        // 11ms ready
    }
}

uint8_t read_button(void)
{
    static uint8_t key_state = 0, key_press;
    uint8_t key_return = KEY_NO; // KEY_NO = 0

    key_press = KEY_INPUT & KEY_MASK; // read the port

    switch (key_state)
    {
        case KEY_STATE_0:  // intial state
            if (key_press != KEY_MASK) key_state = KEY_STATE_1; 
            break;           // key pressed, jump to state 1
        case KEY_STATE_1:    // confirm state
            if (key_press == (KEY_INPUT & KEY_MASK)) // if the key is same
            {
                if (key_press == 0x3E)      // 0b0011 1110
                    key_return = KEY_S1;    // return the key code
                else if (key_press == 0x3D) // 0b0011 1101
                    key_return = KEY_S2;
                else if (key_press == 0x3B) // 0b0011 1011
                    key_return = KEY_S3;
                key_state = KEY_STATE_2;    // switch to release state
            }
            else
                key_state = KEY_STATE_0; // key has been release, swith to initial state
            break;
        case KEY_STATE_2:
            if (key_press == KEY_MASK) key_state = KEY_STATE_0; // key has been release, switch to initial state
            break;
    }

    return key_return;
}

void init(void)
{
    DDRC = 0xFF;  // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    DDRB = 0x00;  // 将 PORTB 设置成输入模式
    PORTB = 0xFF; // 打开内部上拉

    // 设置 Timer 0
    TCCR0B = (1 << CS02);   // Prescaler 256
    TIMSK0 |= (1 << TOIE0); // 打开溢出中断功能
}

void blink(void)
{
    uint8_t i;
    
    for (i=0; i<3; i++)
    {
        PORTC = 0xFF;
        _delay_ms(200);
        PORTC = 0x00;
        _delay_ms(200);
    }
}

int main(void)
{
    uint8_t buttoncode; // 按键码
    uint8_t count = 0;  // 按键计数器

    init(); // 初始化
    sei();  // 开启全局中断

    PORTC = count; // 显示初始值 0

    while (1)
    {
        if (key_scan_time_ok)
        {
            key_scan_time_ok = 0;
            buttoncode = read_button(); // 读键
            if (buttoncode)             // 如果键值不是 0 表明有键被按下，则做下面的处理
            {
                if (buttoncode == KEY_S1) // key S1
                {
                    count++;                    // count 自增
                    if (count > 15) count = 0;   // 超过 15 了回到 0
                }
                if (buttoncode == KEY_S2) { // key S2
                    count--;
                    if (count <= 0) count = 0;
                }
                if (buttoncode == KEY_S3) { // key S3
                    blink();  // 闪 5 次
                }
            }
        }

        PORTC = count;
    }
}
