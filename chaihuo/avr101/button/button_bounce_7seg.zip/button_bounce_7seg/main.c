#include <avr/io.h>
#include <avr/pgmspace.h> // 访问程序空间，后面的 pgm_read_byte 函数就由这个库所提供

// 7-seg LED 段码表
// 位: 7  6 5 4 3 2 1 0
// 段: DP G F E D C B A
// 加额外的 PROGMEM (PROGram MEMory 的缩写)修饰是为了把表格
// 存储在 Flash 存储器(程序代码就是存储在这里的)里而非 RAM 里以节省内存
const uint8_t led_7[16] PROGMEM = {
0x3F, // 0
0x06, // 1
0x5B, // 2
0x4F, // 3
0x66, // 4
0x6D, // 5
0x7D, // 6
0x07, // 7
0x7F, // 8
0x6F, // 9
0x77, // A
0x7C, // b
0x39, // C
0x5E, // d
0x79, // E
0x71  // F
};

void init(void)
{
    DDRC = 0xFF;  // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    DDRB = 0xFF;  // 将 PORTB 设置成输出模式
    PORTB = 0x00;

    DDRD = 0x00;
    PORTD = 0xFF;
}

void display(uint8_t num)
{
    uint8_t temp;
    
    temp = pgm_read_byte(led_7 + num); // 查表并赋给一个临时变量，如果是共阳LED，要把值取反(~是取反操作符)
    PORTC = temp;                    // 把值赋给 IO
    PORTB = (temp >> 6);             // 把数据向右移 6 位才能对应到 PB0 上
}

int main(void)
{
    uint8_t count = 0; // 按键计数器

    init();
    display(count); // 显示 count 的初始值(0)

    while (1)
    {
        while (PIND & 0b00000001) ; // 如果键没有被按下，则程序一直停在此处，处于等待状态，不往下走

        count++;                    // 有键按下了, count 自增
        if (count > 9) count = 0;   // 超过 9 了回到 0

        while ( !(PIND & 0b00000001) ) ; // 如果键被按下但未松开，则程序一直停在此处，不往下走
        display(count);                  // 松开按键后更新显示
    }
}

