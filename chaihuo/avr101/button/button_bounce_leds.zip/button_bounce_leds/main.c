#include <avr/io.h>

void init(void)
{
    DDRC = 0xFF;  // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    DDRB = 0x00;  // 将 PORTB 设置成输出模式
    PORTB = 0xFF;
}

int main(void)
{
    uint8_t count = 0; // 按键计数器

    init();
    PORTC = count;  // 显示 count 的初始值(0)

    while (1)
    {
        while (PINB & 0b00000001) ; // 如果键没有被按下，则程序一直停在此处，处于等待状态，不往下走

        count++;                    // 有键按下了, count 自增
        if (count > 9) count = 0;   // 超过 9 了回到 0

        while ( !(PINB & 0b00000001) ) ; // 如果键被按下但未松开，则程序一直停在此处，不往下走
        PORTC = count;                   // 松开按键后更新显示
    }
}

