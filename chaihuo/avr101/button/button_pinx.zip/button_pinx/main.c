#include <avr/io.h>

void init(void)
{
    DDRC = 0xFF;  // 将 PORTC 设置成输出模式
    PORTC = 0x00;

    DDRB = 0x00;  // 将 PORTB 设置成输入模式
    PORTB = 0xFF; // 打开内部上拉
}

int main(void)
{
    init();

    while (1) PORTC = PINB; // 读 PORTB 的输入，然后输出给 PORTC
}

